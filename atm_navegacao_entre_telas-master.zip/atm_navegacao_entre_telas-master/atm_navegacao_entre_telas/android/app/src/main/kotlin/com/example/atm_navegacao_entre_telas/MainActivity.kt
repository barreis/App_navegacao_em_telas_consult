package com.example.atm_navegacao_entre_telas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
