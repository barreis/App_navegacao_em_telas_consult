import 'package:atm_navegacao_entre_telas/telas/tela_principal.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:atm_navegacao_entre_telas/telas/tela_principal.dart';

void main(){
  runApp(MaterialApp(
    home:TelaPrincipal(),
  ));
}
